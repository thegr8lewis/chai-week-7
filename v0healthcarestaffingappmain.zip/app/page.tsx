"use client"

import { useRef } from "react"
import { HeroSection } from "@/components/hero-section"
import { WhoWeServe } from "@/components/who-we-serve"
import { HowItWorks } from "@/components/how-it-works"
import { DashboardTabs } from "@/components/dashboard-tabs"
import { Footer } from "@/components/footer"
import Link from "next/link"

export default function Home() {
  const dashboardRef = useRef<HTMLDivElement>(null)

  const scrollToDashboard = () => {
    dashboardRef.current?.scrollIntoView({ behavior: "smooth", block: "start" })
  }

  return (
    <main className="min-h-screen">
      <HeroSection onTryDemo={scrollToDashboard} />
      <WhoWeServe />
      <HowItWorks />
      <div ref={dashboardRef} className="animate-in fade-in duration-500">
        <DashboardTabs />
      </div>
      <div className="container mx-auto px-4 py-12 text-center">
        <h2 className="text-2xl font-bold text-foreground mb-6">View Full Dashboards</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl mx-auto">
          <Link href="/dashboard/recruiter">
            <button className="w-full px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-all">
              Recruiter Dashboard
            </button>
          </Link>
          <Link href="/dashboard/caregiver">
            <button className="w-full px-6 py-3 bg-secondary text-white rounded-lg hover:bg-secondary/90 transition-all">
              Caregiver Dashboard
            </button>
          </Link>
          <Link href="/dashboard/client">
            <button className="w-full px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-all">
              Client Dashboard
            </button>
          </Link>
        </div>
      </div>
      <Footer />
    </main>
  )
}
